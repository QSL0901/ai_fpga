import subprocess
import openai

openai.api_key = "YOUR_API_KEY"

def ask_llm(prompt):
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.3
    )
    return response["choices"][0]["message"]["content"]

def run_simulation(verilog_file, tb_file):
    cmd = f"iverilog -o sim.out {verilog_file} {tb_file}"
    compile_res = subprocess.getoutput(cmd)
    run_res = subprocess.getoutput("vvp sim.out")
    return compile_res + "\n" + run_res

def generate_testbench(verilog_code):
    prompt = f"""
Generate a Verilog testbench with clock and basic test cases:

{verilog_code}
"""
    return ask_llm(prompt)

def analyze_error(error_log, code):
    prompt = f"""
Analyze the error and fix the Verilog code:

Code:
{code}

Error:
{error_log}
"""
    return ask_llm(prompt)

def agent_flow(verilog_file):
    with open(verilog_file, "r") as f:
        code = f.read()

    tb = generate_testbench(code)

    with open("tb.v", "w") as f:
        f.write(tb)

    result = run_simulation(verilog_file, "tb.v")
    analysis = analyze_error(result, code)

    print("\n===== RESULT =====\n")
    print(analysis)

if __name__ == "__main__":
    agent_flow("design.v")
