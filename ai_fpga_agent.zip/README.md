# AI FPGA Agent

## Features
- Auto testbench generation
- Simulation with Icarus Verilog
- Error analysis and fix suggestions

## Setup
```bash
pip install openai
sudo apt install iverilog
```

## Run
```bash
python main.py
```
